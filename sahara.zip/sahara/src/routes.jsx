import React from "react/addons"
import {Route, Redirect, DefaultRoute} from "react-router"

// polyfill
if(!Object.assign)
    Object.assign = React.__spread;

// export routes
export default (
    <Route name="app" handler={require("app")}>
      <Route path="/issues" handler={require("app/main")} />
      <Route name="issue" path="/issue/:issueId" handler={require("app/issue")} />
      <Redirect from="/" to="/issues" query={{page: 1}} />
    </Route>
);
