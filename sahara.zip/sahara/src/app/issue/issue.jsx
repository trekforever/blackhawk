import React from 'react/addons'
import Immutable from 'immutable'
import {Link} from 'react-router'
import classNames from 'classnames'
import moment from 'moment'

import Actions from 'common/actions'
import Spinner from 'common/components/spinner'
import _ from 'common/utils'

import './issue.less'


var Issue = React.createClass({
  mixins: [React.addons.PureRenderMixin],
  propTypes: {
    query: React.PropTypes.object,
    params: React.PropTypes.object,
    currentIssue: React.PropTypes.instanceOf(Immutable.Map),
    currentComments: React.PropTypes.instanceOf(Immutable.List)
  },
  getInitialState() {
    return {
      
    };
  },
  componentDidMount() {
    Actions.issues.loadIssue(this.props.params.issueId);
    Actions.issues.loadComments(this.props.params.issueId);
  },
  // Render Functions
  renderSummary() {
    var user = this.props.currentIssue.get('user'),
    userHref = <a className="user" href={user.get('html_url')}>{user.get('login')}</a>;
    return (
      <div className="summary row">
        <div className="meta two columns">
          <img className="avatar" src={ this.props.currentIssue.get('user').get('avatar_url') } />
          <div className="username">{userHref}</div>
        </div>
        <div className="ten columns" dangerouslySetInnerHTML={{__html: this.props.currentIssue.get('body_html')}} />
      </div>
    );
  },
  renderComments() {
    var comments;
    if(!this.props.currentComments) {
      comments = <div className="spinWrapper"><Spinner isActive={true} /></div>;
    } else if(!this.props.currentComments.size) {
      comments = "There are no comments for this issue"
    } else {
      comments = this.props.currentComments.toArray().map((comment) => {
        var user = comment.get('user'),
        userHref = <a className="user" href={user.get('html_url')}>{user.get('login')}</a>;
        return (
          <div className="comment row" key={comment.get('id')}>
            <div className="meta two columns">
              <img className="avatar" src={ comment.get('user').get('avatar_url') } />
            </div>
            <div className="ten columns">
              <div className="row">
                <div className="created twelve columns">
                  Posted by {userHref} on {moment(this.props.currentIssue.get('created_at')).format('dddd, MMM DD, YYYY hh:mm a')}
                </div>
              </div>
              <div className="row">
                <div className="twelve columns" dangerouslySetInnerHTML={{__html: comment.get('body_html')}}/>
              </div>
            </div>
          </div>
        );

      });
    }
    return (
      <div className="comments">
        <h4> Comments </h4>
        { comments }
      </div>
    );
  },
  renderBody() {
    if(!this.props.currentIssue) {
      return <div className="spinWrapper"><Spinner isActive={true} /></div>;
    }
    var user = this.props.currentIssue.get('user'),
    userHref = <a className="user" href={user.get('html_url')}>{user.get('login')}</a>,
    issueStyle = {color: this.props.currentIssue.get('state') === "open" ? "#6cc644" : "#bd2c00"},
    issueType = this.props.currentIssue.get('pull_request') ? "Pull Request" : "Issue",
    type =  issueType === "Pull Request" ? <span style={issueStyle} className="icon-git-pull-request" /> : this.props.currentIssue.get('state') === "open" ? <span style={issueStyle} className="icon-issue-opened" /> : <span style={issueStyle} className="icon-issue-closed" />,
    labels = this.props.currentIssue.get('labels').map((label) => {
        var labelStyle = {'backgroundColor': `#${label.get('color')}`, 'color': _.determineForegroundColor(label.get('color'))};
        return <li key={label.get('name')} style={labelStyle}>{label.get('name')}</li>
      });
    return (
      <div className="body">
        <h1 className="title">{type} {`${this.props.currentIssue.get('title')}`}</h1>
        <p className="meta">#{this.props.currentIssue.get('number')} Created by {userHref} on {moment(this.props.currentIssue.get('created_at')).format('dddd, MMM DD, YYYY hh:mm a')} &middot; <span className="status" style={issueStyle}>{`${this.props.currentIssue.get('state')} ${issueType}`}</span>&middot;<span className="back"><Link to='/issues' query={{state: this.props.currentIssue.get('state')}}> <i className="icon-back" /> View all {this.props.currentIssue.get('state')} issues</Link></span></p>
        <ul className="labels">{labels}</ul>
        { this.renderSummary() }
        { this.renderComments() }
      </div>
    );
  },
  render() {
    return (
      <div className="issue container">
        { this.renderBody() }
      </div>
    );
  }
});
export default Issue;
