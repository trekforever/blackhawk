import React from 'react/addons'
import Immutable from 'immutable'
import Reflux from 'reflux'
import classNames from 'classnames'
import moment from 'moment'

import Actions from 'common/actions'
import Spinner from 'common/components/spinner'
import _ from 'common/utils'

import './header.less'

var Header = React.createClass({
  mixins: [React.addons.PureRenderMixin],
  propTypes: {
  },
  getInitialState() {
    return {
    };
  },
  componentDidMount() {
    //Get Repo Info
    Actions.issues.loadRepo();
  },
  // Render Functions
  render() {
    if(!this.props.repo) {
      return null;
    }
    return (
      <nav className="header">
        <div className="container">
          <h1 className="title">{`Github Issues - ${this.props.repo.get('full_name')}`}</h1>
          <div className="meta">
            <div className="info"><span className="icon-eye" /> {_.formatNumber(this.props.repo.get('subscribers_count'))} &middot; </div>
            <div className="info"><span className="icon-star" /> {_.formatNumber(this.props.repo.get('stargazers_count'))} &middot; </div>
            <div className="info"><span className="icon-repo-forked" /> {_.formatNumber(this.props.repo.get('forks'))}</div>
          </div>
        </div>
      </nav>
    );
  }
});
export default Header;
