import React from 'react/addons'
import {RouteHandler} from "react-router"
import Reflux from 'reflux'

import Header from 'app/header'
import Store from 'common/store'
import 'skeleton-less/less/skeleton.less'
import './app.less'

var Application = React.createClass({
  mixins: [React.addons.PureRenderMixin, Reflux.listenTo(Store, "storeChangeListener")],
  storeChangeListener(delta) {
    this.setState(delta);
  },
  getInitialState() {
    return {
      issues : null,
      pages: 0,
      repo: null,
      currentIssue: null,
      currentComments: null
    };
  },
  render() {
      return (
        <div className="app">
          <Header repo={this.state.repo} />
          <RouteHandler {...this.state} />
        </div>
      );
  }
});
export default Application;
