import React from 'react/addons'
import classNames from 'classnames'

import './filter.less'

var Filter = React.createClass({
  mixins: [React.addons.PureRenderMixin],
  propTypes: {
    state: React.PropTypes.string,
    onTypeChg: React.PropTypes.func
  },
  getInitialState() {
    return {
    };
  },
  filterType(type) {
    if(type !== this.props.state) {
      this.props.onTypeChg(type);
    }
  },
  // Render Functions
  render() {
    var cx = (type) => {
      return classNames({
        'active' : this.props.state === type
      });
    };
    return (
      <div className="filter">
        <ul className="stateSelect">
          <li onClick={this.filterType.bind(null, 'open')} className={cx('open')}>Active</li>
          <li onClick={this.filterType.bind(null, 'closed')} className={cx('closed')}>Closed</li>
        </ul>
      </div>
    );
  }
});
export default Filter;
