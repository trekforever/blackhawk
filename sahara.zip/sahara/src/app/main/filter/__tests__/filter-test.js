var React = require('react/addons');
var TestUtils = require("react/lib/ReactTestUtils");

describe('Filter', () => {
  var Filter;
  beforeEach(() => {
    Filter = require('app/main/filter');
  });

  it("Should render", () => {
    var FilterInstance = TestUtils.renderIntoDocument(<Filter state='open' />);
  });

  it("Valid view", () => {
    var FilterInstance = TestUtils.renderIntoDocument(<Filter state='open' />);
    expect(FilterInstance.getDOMNode().querySelector('.stateSelect .active').textContent).toBe("Active");
  });

});