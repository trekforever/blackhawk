import React from 'react/addons'
import Reflux from 'reflux'
import {Link, Navigation} from 'react-router'
import classNames from 'classnames'
import moment from 'moment'
import Immutable from 'immutable'

import Filter from "app/main/filter"
import Actions from 'common/actions'
import Spinner from 'common/components/spinner'
import _ from 'common/utils'


import './main.less'

var Main = React.createClass({
  mixins: [React.addons.PureRenderMixin, Navigation],
  propTypes: {
    query: React.PropTypes.object,
    issues: React.PropTypes.instanceOf(Immutable.List),
    pages: React.PropTypes.oneOfType([React.PropTypes.string, React.PropTypes.number]),
    state: React.PropTypes.string
  },
  getInitialState() {
    return {
      currentPage: _.parseInt(this.props.query.page) || 1,
      state: this.props.query.state || "open"
    };
  },
  componentDidMount() {
    // Set up
    // Fetch inital list of issues
    Actions.issues.loadList(25, this.state.currentPage, this.state.state);
  },
  componentWillReceiveProps(nextProps) {
    if((nextProps.query.page && _.parseInt(nextProps.query.page) !== _.parseInt(this.state.currentPage)) || 
      (nextProps.query.state && nextProps.query.state !== this.props.query.state)) {
      this.setState({
        currentPage: _.parseInt(nextProps.query.page),
        state: nextProps.query.state
      });
      window.scroll(0,0);
      Actions.issues.loadList(25, nextProps.query.page, nextProps.query.state || "open");  
    }
  },
  // Custom Functions
  onTypeChg(type) {
    this.transitionTo(`/issues?page=1&state=${type}`)
  },
  // Render Functions
  renderList() {
    if(!this.props.issues) {
      return ;
    }
    var list = this.props.issues.map((issue) => {
      var labels = issue.get('labels').map((label) => {
        var labelStyle = {'backgroundColor': `#${label.get('color')}`, 'color': _.determineForegroundColor(label.get('color'))};
        return <li key={label.get('name')} style={labelStyle}>{label.get('name')}</li>
      });
      var user = issue.get('user'),
      userHref = <a href={user.get('html_url')}>{user.get('login')}</a>,
      issueStyle = {color: issue.get('state') === "open" ? "#6cc644" : "#bd2c00"},
      type = issue.get('pull_request') ? <span style={issueStyle} className="icon-git-pull-request" /> : issue.get('state') === "open" ? <span style={issueStyle} className="icon-issue-opened" /> : <span style={issueStyle} className="icon-issue-closed" />;
      return (
        <article key={issue.get('number')} className="issue twelve columns">
          <img className="avatar" src={ user.get('avatar_url') } />
          <div className="info">
            <h3 className="title"><Link to="issue" params={{issueId: issue.get('number')}}> {`#${issue.get('number')} - ${issue.get('title')}`}</Link></h3>
            <ul className ="labels">
            { labels }
            </ul>
            <p className="summary">{_.truncateTxt(issue.get('body_text'))}</p>
            <p className="meta">Created by {userHref} {moment(issue.get('created_at')).fromNow()} &middot; <span className="icon-comment">{issue.get('comments')}</span> <span>&middot; {type}</span></p>
          </div>
        </article>
      );
    });
    return (
      <div className="row">
        {list}
      </div>
    );
  },
  renderPagination() {
    var currentPage = this.state.currentPage || 1,
    totalPages = _.max([currentPage, _.parseInt(this.props.pages)]),
    pagination = [],
    cx = (ind) => {
      return classNames({
        "current" : ind == this.state.currentPage
      });
    };
    // First Link
    pagination.push("<<");
    // Calculate before 2 pages
    if(this.state.currentPage > 3) {
      pagination.push('...');
    }
    var offset = (this.state.currentPage - 3) > 0 ? (this.state.currentPage - 3) : 1;
    for(var i = offset; i !== this.state.currentPage; i++) {
      pagination.push(i);
    }
    // current page
    pagination.push(this.state.currentPage);
    // Calculate after 2 pages
    for(var i=this.state.currentPage+1; i <= this.props.pages && i < (this.state.currentPage + 4); i++) {
      pagination.push(i);
    }
    if(this.props.pages - this.state.currentPage > 3) {
      pagination.push('...');
    }
    // Last Link
    pagination.push(">>");

    pagination = pagination.map((ind, pos) => {
      var page = ind;
      if(ind === "<<") {
        // first page
        page = 1;
      }
      if(ind === ">>") {
        // last page
        page = this.props.pages;
      }

      if(ind === "...") {
        return <li key={`sep${pos}`} className="separator">...</li>
      }
      return <li key={`issue${pos}`}><Link className={cx(ind)} to="/issues" query={{page: page, state: this.props.query.state || "open"}}>{ind}</Link></li>;
    });
    return (
      <div className="navWrapper row">
        <ul className="nav">
          { pagination }
        </ul>
      </div>
    );
  },
  renderFilter() {
    return <Filter state={this.state.state} onTypeChg={this.onTypeChg} />;
  },
  renderBody() {
    if(!this.props.issues) {
      return <div className="spinWrapper"><Spinner isActive={true} /></div>;
    }
    if(!this.props.issues.size) {
      return <div className="row"><div className="twelve columns">{`There are no ${this.state.state} issues for this repo`}</div></div>;
    }
    return (
      <div className="body">
        { this.renderList() }
        { this.renderPagination() }
      </div>
    );
  },
  render() {
    return (
      <div className="content container">
        { this.renderFilter() }
        { this.renderBody() }
      </div>
    );
  }
});
export default Main;
