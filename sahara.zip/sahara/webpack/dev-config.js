module.exports = require("./common")({
    devServer: true,
    hotComponents: true,
    devtool: "source-map",
    debug: true,
    commonsChunk: true,
    separateStylesheet: false,
    port: 2992
});